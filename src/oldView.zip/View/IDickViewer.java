package View;

public interface IDickViewer {

  public void renderSuccess(String type);

  public void renderError(String errorMessage);

}
